#include <stdio.h>

int somma (int num);

int main(){
  int k;
  printf("Inserisci numero: ");  
  scanf("%d",&k);
  printf("La somma dei primi %d numeri e': %d",k,somma(k));
  return 0;
}

int somma (int num){
  if (num==0)
    return 0;
  else
    return num + somma(num-1);
}